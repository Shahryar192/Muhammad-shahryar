import os

from flask import Flask, render_template, request, redirect, url_for
from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session, sessionmaker

app = Flask(__name__)
#postgress
engine = create_engine("mysql+pymysql://root:Admin1234@localhost:3306/python_for_web")


db = scoped_session(sessionmaker(bind=engine))





@app.route("/")
def index():
    return render_template("index.html")

@app.route("/collection")
def collection():
    return render_template("collection.html")
@app.route("/racing")
def racing():
    return render_template("racing_boots.html")
@app.route("/contact")
def contact():
    return render_template("contact.html")

if __name__ == "__main__":


    app.run(debug=True)